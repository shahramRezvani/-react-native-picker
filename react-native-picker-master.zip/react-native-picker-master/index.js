module.exports = require('./lib/singlePicker.js');
